// memanggil header
#include "header.h"

// program utama 
int main()
{
    input();    // masuk ke prosedur input

    return 0;   // akhir program
}